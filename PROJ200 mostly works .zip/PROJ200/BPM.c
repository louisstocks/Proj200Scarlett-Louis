#include "BPM.h"

void init_BPM(void) {
    // Initialize any BPM-related settings if necessary
    // This function is currently empty but required for linking
}

#define THRESHOLD 2000  // Adjust based on sensor ADC values

int calculate_BPM(unsigned short adc_value) {
    static int last_beat_time = 0;
    static int bpm = 0;
    static int beat_count = 0;
    static int prev_time = 0;

    int current_time = get_millis();  // Uses get_millis() from Main.c

    if (adc_value > THRESHOLD) {
        if ((current_time - prev_time) > 300) { // Debounce to avoid noise
            beat_count++;
            if (beat_count >= 2) {
                bpm = (60000 / (current_time - last_beat_time)); // Convert to BPM
                last_beat_time = current_time;
            }
            prev_time = current_time;
        }
    }
    return bpm;
}

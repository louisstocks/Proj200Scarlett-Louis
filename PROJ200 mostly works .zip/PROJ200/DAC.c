#include "DAC.h"

#ifndef RED_LED_PIN
#define RED_LED_PIN 5   // Set this to the appropriate pin for your board
#endif

#ifndef IR_LED_PIN
#define IR_LED_PIN 14    // Set this to the appropriate pin for your board
#endif

void init_DAC(void) {

    // Enable the DAC clock on APB1.
    RCC->APB1ENR |= RCC_APB1ENR_DACEN;
  
    // Enable both DAC channels.
    DAC->CR |= DAC_CR_EN1 | DAC_CR_EN2;

 
    // Set both DAC channels to their maximum output (3.3V).
    DAC->DHR12R1 = 0xFFF; // DAC channel 1.
    DAC->DHR12R2 = 0xFFF; // DAC channel 2.

}

#ifndef USART_H
#define USART_H

#include <stdint.h>

// Initializes USART1 (e.g., for debugging on PA9/PA10)
void initUSART(void);

// Sends a single character over USART1
void USART_sendChar(char c);

 
// Sends a null-terminated string over USART1
void USART_sendString(const char *s);


#endif // USART_H
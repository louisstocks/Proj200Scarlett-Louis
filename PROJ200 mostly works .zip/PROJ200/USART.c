#include "USART.h"

#include <stm32f429xx.h>

 

void initUSART(void) {

    // Enable clocks for USART1 and GPIOA
    RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

   

    // Configure PA9 (TX) and PA10 (RX) for alternate function mode (AF7 for USART1)
    GPIOA->MODER &= ~((3UL << (2 * 9)) | (3UL << (2 * 10)));
    GPIOA->MODER |= ((2UL << (2 * 9)) | (2UL << (2 * 10)));

   
    // Set alternate function to AF7 (USART1) for PA9 and PA10.
    // PA9 and PA10 are in AFR[1] (pins 8-15)
    GPIOA->AFR[1] &= ~((0xF << (4 * (9 - 8))) | (0xF << (4 * (10 - 8))));
    GPIOA->AFR[1] |= ((7 << (4 * (9 - 8))) | (7 << (4 * (10 - 8))));

   
    // Configure USART1 baud rate.
    // Assuming PCLK2 = 84 MHz and a target baud rate of 115200,
    // USARTDIV = 84000000 / 115200 � 729.17. For simplicity, we set BRR to 729.
    USART1->BRR = 729;

   
    // Enable USART1 transmitter and receiver, then enable USART1.
    USART1->CR1 = USART_CR1_TE | USART_CR1_RE;
    USART1->CR1 |= USART_CR1_UE;

}

 

void USART_sendChar(char c) {

    // Wait until the transmit data register is empty
    while (!(USART1->SR & USART_SR_TXE));
    USART1->DR = c;
}

 

void USART_sendString(const char *s) {

    while (*s) {
        USART_sendChar(*s++);
    }

}
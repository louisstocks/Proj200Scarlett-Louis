#include "LED.h"

#define RED_LED_PIN 5

#define IR_LED_PIN  14

void LEDInit(void) {
    // Enable clock for GPIOA
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    // Configure PA5 as output (clear and set MODER)
    GPIOA->MODER &= ~(3UL << (5 * 2));  // Clear MODER5
    GPIOA->MODER |= (1UL << (5 * 2));   // Set MODER5 to 01 (output mode)

    // Set PA5 output to high (turn on LED initially)
    GPIOA->BSRR = (1UL << 5);
}

#ifndef LED_H
#define LED_H

#include "stm32f4xx.h"  // Change based on your STM32 series

void LEDInit(void);

#endif

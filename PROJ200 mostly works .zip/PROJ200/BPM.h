#ifndef BPM_H
#define BPM_H

#include <stdint.h>  // Include this to define uint32_t

void init_BPM(void);
int calculate_BPM(unsigned short adc_value);

// Declare get_millis() so BPM.c can use it
extern uint32_t get_millis(void);

#endif

#ifndef DAC_H

#define DAC_H

#include <stm32f429xx.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <stm32f429xx.h>

// Initializes the DAC to output 3.3V (max value) on both channels.
void init_DAC(void);

#endif // DAC_H
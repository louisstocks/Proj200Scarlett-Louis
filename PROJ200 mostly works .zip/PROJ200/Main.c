#include "stm32f4xx.h"
#include "ADC.h"
#include "LCD.h"
#include "BPM.h"
#include "USART.h"
#include "LED.h"
#include "DAC.h"
#include <stdio.h>

#define SAMPLE_PERIOD_MS 100
#define MIC_CHANNEL 3

volatile uint32_t systick_ms = 0;  // System tick counter

void SysTick_Handler(void) {
    systick_ms++;  
}

uint32_t get_millis(void) {
    return systick_ms;
}

void delay_ms(uint32_t ms) {
    uint32_t start = get_millis();
    while (get_millis() - start < ms);
}

void init_system(void) {
    init_ADC();
    initLCD();
    init_BPM();
    initUSART();
    LEDInit();
    init_DAC();
    SysTick_Config(SystemCoreClock / 1000);
}

int main(void) {   // <--- This must be present
    char bpm_str[16];

    init_system();  

    while (1) {
        unsigned short adc_value = read_adc(MIC_CHANNEL);
        int bpm = calculate_BPM(adc_value);  

        sprintf(bpm_str, "BPM: %d", bpm);
        LCD_CLR();
        printLCD(bpm_str);

        delay_ms(SAMPLE_PERIOD_MS);
    }
}

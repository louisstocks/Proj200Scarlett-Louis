#include "ADC.h"

 

void init_ADC(void) {

    // Enable GPIOC clock (assuming your ADC input is on a pin in GPIOC)
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
	
    // For example, if your ADC input is on PC13, set it to analog mode:
    GPIOC->MODER |= (3UL << (3 * 2));

    // Enable ADC1 clock

    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;
    ADC1->CR2 = 0;
    ADC1->CR2 |= ADC_CR2_ADON;  // Turn on ADC1

}

unsigned short read_adc(int channel) {

    // Clear previous channel selection in the regular sequence register (SQR3)
    ADC1->SQR3 &= ~(0x1F);
	
    // Set the new channel (assumes channel is 0-31, but typically 0-15 for STM32F4)
    ADC1->SQR3 |= (channel);

    // Start the conversion
    ADC1->CR2 |= ADC_CR2_SWSTART;

    // Wait until the conversion is complete (EOC flag set)
    while (!(ADC1->SR & ADC_SR_EOC)) {

        __NOP();

    }

    // Return the conversion result
    return (unsigned short)(ADC1->DR);

}

 
#ifndef ADC_H

#define ADC_H

#include <stm32f4xx.h>

#define ADC_input_port  GPIOC

#define ADC_input_pin   0
#define ADC_Channel     10
#define LDR_CHANNEL     10
#define POT_CHANNEL     0
#define MIC_CHANNEL     3

 

#define INPUT_CHANNEL   13

 

void init_ADC(void);

unsigned short read_adc(int channel);

 

#endif